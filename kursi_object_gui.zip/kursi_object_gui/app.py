import streamlit as st
import os
import random
import cv2
from utils import load_image, classify_object
import numpy as np

st.set_page_config(page_title="Object Identifier Module")

st.title("Object Identifier Module")
st.subheader("Select an object for analysis:")

col1, col2, col3 = st.columns([2, 2, 2])

dataset_path = "dataset"

def get_all_images():
    image_list = []
    for category in os.listdir(dataset_path):
        for img in os.listdir(os.path.join(dataset_path, category)):
            image_list.append(os.path.join(dataset_path, category, img))
    return image_list

def analyze_image(img_path):
    img = load_image(img_path)
    belt, label = classify_object(img)
    return img, belt, label

if st.button("Analyze Random Object"):
    images = get_all_images()
    selected = random.choice(images)
    img, belt, label = analyze_image(selected)
    st.image(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), caption="Analyzed Image")
    st.success(f"Sent to Conveyor Belt {belt} ({label})")

if st.button("Process 10 Random Objects"):
    images = random.sample(get_all_images(), 10)
    for i, img_path in enumerate(images):
        img, belt, label = analyze_image(img_path)
        st.image(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), caption=f"{os.path.basename(img_path)} → Belt {belt} ({label})")

uploaded = st.file_uploader("Upload Your Own Image", type=["jpg", "png", "jpeg"])
if uploaded:
    file_bytes = np.asarray(bytearray(uploaded.read()), dtype=np.uint8)
    img = cv2.imdecode(file_bytes, 1)
    belt, label = classify_object(img)
    st.image(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), caption="Uploaded Image")
    st.success(f"Sent to Conveyor Belt {belt} ({label})")
