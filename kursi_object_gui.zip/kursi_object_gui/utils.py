import cv2
import numpy as np

def load_image(image_path):
    image = cv2.imread(image_path)
    return image

def average_brightness(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return np.mean(gray)

def is_colorful(image, threshold=40):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    std_dev = np.std(hsv[:, :, 0])
    return std_dev > threshold

def classify_object(image):
    brightness = average_brightness(image)

    if not is_colorful(image):
        return 'A', 'Black Objects'
    elif brightness > 170:
        return 'B', 'Transparent Objects'
    else:
        return 'C', 'Colorful Objects'
